﻿//Task 01

var integer = 1234567890, floatNumber = 1.4,
booleanTrue = true;
booleanFalse = false;
var undLit;
var nullLit=null;
var string = "abc";
var arrayLiteral = ["a", "b"];
var objectType = { a: '123', 'b': '789', c: 12 };
console.log("Task 1");
console.log(integer);
console.log(floatNumber);
console.log(booleanTrue);
console.log(booleanFalse);
console.log(undLit);
console.log(nullLit);
console.log(string);
console.log(undLit + integer);
console.log(arrayLiteral.join(", "));
console.log(objectType.a+" "+objectType.b+" "+objectType.c)

//Task 02
console.log("Task 2");
var joey = '"How you doin\'?", Joey said.';
console.log(joey);

//Task 0
console.log("Task 3");
console.log("integer:"+typeof (integer));
console.log("booleantrue:"+typeof (booleanTrue));
console.log("booleanFalse:"+typeof (booleanFalse));
console.log("Undefined literal:"+typeof (undLit));
console.log("Null literal:"+typeof (nullLit));
console.log("String:"+typeof (string));
console.log("Array:"+typeof (arrayLiteral));
console.log("Joey string:"+typeof (joey));
console.log("Object:"+typeof (objectType));
//Task 04 
console.log("Task 4");
var und;
console.log(und);
var nullVar = null;
console.log(nullVar);
