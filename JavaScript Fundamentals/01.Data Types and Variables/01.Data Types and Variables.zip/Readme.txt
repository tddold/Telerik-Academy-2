The files are produced with Visual studio. 
You can just open the html file in chrome and press F12
and check the homework with the console. 