﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Problem 6.* Matrix class
//Write a class Matrix, to hold a matrix of integers.
//Overload the operators for adding, subtracting and multiplying of matrices,
//indexer for accessing the matrix content and ToString().


class matrixClass
{
    static void Main(string[] args)
    {
    }
}

